#ifndef COM_FACE_REGISTER_H
#define COM_FACE_REGISTER_H
#include "face_register.h"

class Com_face_register
{
public:
    Com_face_register();

    static face_register *p_face_register;
    static void InitForm();

};

#endif // COM_FACE_REGISTER_H
