#ifndef COM_MAIN_WINDOW_H
#define COM_MAIN_WINDOW_H
#include"main_window.h"

class Com_main_window
{
public:
    Com_main_window();
    static main_window *p_main_window;

    static void  InitForm();
};

#endif // COM_MAIN_WINDOW_H
