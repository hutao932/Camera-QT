#ifndef COM_FACE_DELETION_H
#define COM_FACE_DELETION_H
#include "face_deletion.h"

class Com_face_deletion
{
public:
    Com_face_deletion();
    static face_deletion *p_face_deletion;
    static void InitForm();
};

#endif // COM_FACE_DELETION
