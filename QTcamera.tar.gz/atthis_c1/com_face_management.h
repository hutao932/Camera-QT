#ifndef COM_FACE_MANAGEMENT_H
#define COM_FACE_MANAGEMENT_H
#include "face_management.h"

class Com_face_management
{
public:
    Com_face_management();
    static face_management *p_face_management;

    static void  InitForm();
};

#endif // COM_FACE_MANAGEMENT_H
