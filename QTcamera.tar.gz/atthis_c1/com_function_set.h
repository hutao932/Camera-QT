#ifndef COM_FUNCTION_SET_H
#define COM_FUNCTION_SET_H
#include"function_set.h"

class Com_function_set
{
public:
    Com_function_set();

    static function_set *p_function_set;

    static void InitForm();
};

#endif // COM_FUNCTION_SET_H
