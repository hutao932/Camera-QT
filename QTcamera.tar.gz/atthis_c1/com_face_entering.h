#ifndef COM_FACE_ENTERING_H
#define COM_FACE_ENTERING_H
#include "face_entering.h"

class Com_face_entering
{
public:
    Com_face_entering();
    static face_entering* p_face_entering;
    static void InitForm();
};

#endif // COM_FACE_ENTERING_H
